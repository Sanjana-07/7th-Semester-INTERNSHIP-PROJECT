<!DOCTYPE html>
<html>
<head>
<title>CIS</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<style>
body
{
     background-image: url("img/1d.jpg");
    background-repeat: no-repeat;
    background-size:cover;
}

h1
{
   color:white;
   font-size: 70px;
   margin-top: 20%;
}          
nav 
{ 
	width:100%;
    height:80px;
    background-color:darkblue;
    line-height: 50px;
   
}
nav ul
{
    float: right;
    margin-right:30px
}
nav ul li
{
    list-style-type: none;
    display:inline-block;
    transition: 0.8s all;
                
}
nav ul li a
{
    text-decoration: none;
    color: #fff;
    padding: 40px;
}
nav ul li:hover
{
    background-color: #f39d1a;
}

footer 
{
  text-align: center;
  padding: 3px;
  background-color: black;
  color: white;
  margin-top: 70%;
  margin-right: 
}
#d1
{
  text-align: center;
  font-family: verdana;
}
</style>
</head>
<body>
<div id="main">
    <nav>  
    	<ul>
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">logout</a></li>
            
        </ul>
    </nav>
</div>
<hr>




<footer>
  <p>CopyRight@2020 collegeinternshipsystem.in</p>
 </footer>

</body>
</html>